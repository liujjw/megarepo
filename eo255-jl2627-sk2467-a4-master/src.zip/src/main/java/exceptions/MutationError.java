package exceptions;

/*
 An exception indicating mutation had issue
 */

public class MutationError extends Exception {
	private static final long serialVersionUID = 42L;
}
