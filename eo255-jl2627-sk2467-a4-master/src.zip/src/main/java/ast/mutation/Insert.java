package ast.mutation;

import ast.Mutation;
import ast.Program;

public class Insert extends AbstractMutation {
    public Program mutate(Program root, int index) {
        throw new UnsupportedOperationException("Insert not implemented.");
    }

}
